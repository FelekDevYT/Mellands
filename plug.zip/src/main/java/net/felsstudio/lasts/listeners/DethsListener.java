package net.felsstudio.lasts.listeners;

import net.felsstudio.lasts.Lasts;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Date;

public class DethsListener implements Listener {
    final Lasts plugin;

    public DethsListener(Lasts plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onLeave(PlayerQuitEvent e) {
        plugin.getConfig().set(e.getPlayer().getName(), new Date());
    }
}
