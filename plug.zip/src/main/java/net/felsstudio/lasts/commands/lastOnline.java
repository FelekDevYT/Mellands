package net.felsstudio.lasts.commands;

import net.felsstudio.lasts.Lasts;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class lastOnline implements CommandExecutor {
    private final Lasts plugin;

    public lastOnline(Lasts plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {//lastonline MrNullYT

        Player p = (Player) sender;

        p.sendMessage((String) plugin.getConfig().get(args[0]));

        return false;
    }
}
