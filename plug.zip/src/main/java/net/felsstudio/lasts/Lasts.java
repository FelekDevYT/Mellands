package net.felsstudio.lasts;

import net.felsstudio.lasts.commands.lastOnline;
import net.felsstudio.lasts.listeners.DethsListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class Lasts extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        getCommand("lastonline").setExecutor(new lastOnline(this));

        getServer().getPluginManager().registerEvents(new DethsListener(this),this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
